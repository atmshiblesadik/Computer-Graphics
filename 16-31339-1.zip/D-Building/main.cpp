#include<windows.h>
#include<GL/glut.h>
#include<stdlib.h>
#include<bits/stdc++.h>
using namespace std;
const double cor = 0.0666666667;

void rec(pair<double,double> a,pair<double,double> b,pair<double,double> c,pair<double,double> d,double R,double G,double B){
        glBegin(GL_POLYGON);
        glColor3ub(R,G,B);
        glVertex2d(a.first,a.second);
        glVertex2d(b.first,b.second);
        glVertex2d(c.first,c.second);
        glVertex2d(d.first,d.second);
        glEnd();
}
void tri(pair<double,double> a,pair<double,double> b,pair<double,double> c,double R,double G,double B){
        glBegin(GL_POLYGON);
        glColor3ub(R,G,B);
        glVertex2d(a.first,a.second);
        glVertex2d(b.first,b.second);
        glVertex2d(c.first,c.second);
        glEnd();
}
void line(pair<double,double> a,pair<double,double> b,double R,double G,double B){
        glBegin(GL_LINES);
        glColor3ub(R,G,B);
        glVertex2d(a.first,a.second);
        glVertex2d(b.first,b.second);
        glEnd();
}
void display(){
        glClearColor(1.0f,1.0f,1.0f,1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        rec({-8*cor,-10*cor},{12*cor,-10*cor},{12*cor,7*cor},{-8*cor,7*cor},255, 51, 0);///Front-View

        rec({-12*cor,-10*cor},{-8*cor,-10*cor},{-8*cor,7*cor},{-12*cor,6*cor},0,51,204);///Side-View

        rec({-8*cor,-6*cor},{12*cor,-6*cor},{12*cor,-2*cor},{-8*cor,-2*cor},102, 255, 255);///1st-Floor-Front
        rec({-8*cor,-2*cor},{12*cor,-2*cor},{12*cor,2*cor},{-8*cor,2*cor},204, 255, 204);///2nd-Floor-Front
        rec({-8*cor,2*cor},{12*cor,2*cor},{12*cor,7*cor},{-8*cor,7*cor},0, 204, 153);///3rd-Floor-Front

        rec({-12*cor,-7*cor},{-8*cor,-6*cor},{-8*cor,-2*cor},{-12*cor,-3*cor},102, 155, 0);///1st-Floor-Side
        rec({-12*cor,-3*cor},{-8*cor,-2*cor},{-8*cor,2*cor},{-12*cor,1*cor},5, 204, 255);///2nd-Floor-Side
        rec({-12*cor,1*cor},{-8*cor,2*cor},{-8*cor,7*cor},{-12*cor,6*cor},153, 204, 255);///3rd-Floor-Side

        rec({-3*cor,-10*cor},{3*cor,-10*cor},{3*cor,-6*cor},{-3*cor,-6*cor},0,51,204);///Door

        ///AIUB Text
        ///A
        line({-7*cor,7*cor},{-5*cor,11*cor},255, 0, 0);
        line({-5*cor,11*cor},{-3*cor,7*cor},255, 0, 0);
        line({-6*cor,9*cor},{-4*cor,9*cor},255, 0, 0);
        ///I
        line({-2*cor,11*cor},{-0*cor,11*cor},255, 0, 0);
        line({-2*cor,7*cor},{-0*cor,7*cor},255, 0, 0);
        line({-1*cor,11*cor},{-1*cor,7*cor},255, 0, 0);
        ///U
        line({1*cor,11*cor},{1*cor,7*cor},255, 0, 0);
        line({4*cor,11*cor},{4*cor,7*cor},255, 0, 0);
        line({1*cor,7*cor},{4*cor,7*cor},255, 0, 0);
        ///B
        line({6*cor,11*cor},{6*cor,7*cor},255, 0, 0);
        tri({6*cor,9*cor},{8*cor,10*cor},{6*cor,11*cor},255, 0, 0);
        tri({6*cor,7*cor},{8*cor,8*cor},{6*cor,9*cor},255, 0, 0);
        glFlush();
}
int main(int argc,char** argv){
    glutInit(&argc,argv);
    glutCreateWindow("D-Building");
    glutInitWindowSize(1024,1024);
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
